<?php
require_once realpath(__DIR__) . '/Autoload.php';

TechAPIAutoloader::register();

use TechAPI\Constant;
use TechAPI\Client;
use TechAPI\Auth\ClientCredentials;

// config api
Constant::configs(array(
    //'mode'            => Constant::MODE_LIVE,
    'mode' => Constant::MODE_LIVE,
    'connect_timeout' => 15,
    'enable_cache' => false,
    'enable_log' => false,
    'log_path' => realpath(__DIR__) . '/logs'
));

// config client and authorization grant type
function getTechAuthorization($clientid = '', $secret = '')
{
    $client = new Client(
        $clientid,
        $secret,
        array('send_brandname', 'send_brandname_otp')
    );

    return new ClientCredentials($client);
}
